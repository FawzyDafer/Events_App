export const navigation = [
  {
    text: 'الرئيسية',
    path: '/home',
    icon: 'home'
  },
   {
    text: 'الفعليات',
    path: '/event',
    icon: 'smalliconslayout'
  },
  {
    text: 'المنظمين',
    path: '/organizer',
    icon: 'contentlayout'
  },
  // {
  //   text: 'Examples',
  //   icon: 'folder',
  //   items: [
  //     {
  //       text: 'Profile',
  //       path: '/profile'
  //     },
  //     {
  //       text: 'Tasks',
  //       path: '/tasks'
  //     }
  //   ]
  // }
];
